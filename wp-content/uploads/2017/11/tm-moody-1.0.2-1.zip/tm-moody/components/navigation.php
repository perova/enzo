<div id="page-navigation" <?php Insight::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Insight::menu_primary(); ?>
	</nav>
</div>
