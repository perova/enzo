<div id="page-close-main-menu" class="page-close-main-menu">
	<i class="icon-close"></i>
</div>
<div class="page-off-canvas-main-menu">
	<div id="page-navigation" <?php Insight::navigation_class(); ?>>
		<?php Insight::off_canvas_menu_primary(); ?>
	</div>
</div>
