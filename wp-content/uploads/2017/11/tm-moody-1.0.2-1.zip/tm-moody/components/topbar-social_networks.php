<div class="top-bar-social-network"><?php Insight_Templates::social_icons( array(
	                                                                           'display'        => 'icon',
	                                                                           'tooltip_enable' => false,
                                                                           ) ); ?></div>
