<div class="post-comments-number">
	<span class="comment-icon fa fa-comment"></span><?php echo get_comments_number(); ?>
</div>
