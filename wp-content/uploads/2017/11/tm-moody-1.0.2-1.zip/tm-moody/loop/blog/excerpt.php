<div class="post-excerpt">
	<?php Insight_Templates::excerpt( array(
		                                  'limit' => 100,
		                                  'type'  => 'character',
	                                  ) ); ?>
</div>
