<div class="product-overlay">
	<i class="fa fa-search"></i>
</div>
