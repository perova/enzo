<?php do_action( 'insight/body' ); ?>
