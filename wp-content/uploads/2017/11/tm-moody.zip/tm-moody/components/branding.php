<div <?php Insight::branding_class(); ?>>
	<div class="branding__logo">
		<?php Insight::branding_logo(); ?>
	</div>
</div>
