<div class="post-author">
	<?php echo esc_html__( 'by', 'tm-moody' ) . ' ' . get_the_author(); ?>
</div>
