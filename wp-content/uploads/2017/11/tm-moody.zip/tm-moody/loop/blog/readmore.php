<div class="post-read-more">
	<a href="<?php the_permalink(); ?>">
											<span class="btn-text">
												<?php esc_html_e( 'Read More', 'tm-moody' ); ?>
											</span>
		<span class="btn-icon icon-arrow-2-right">
											</span>
	</a>
</div>
